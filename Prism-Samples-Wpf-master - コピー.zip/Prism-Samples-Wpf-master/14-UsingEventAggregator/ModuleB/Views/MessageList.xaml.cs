﻿using System.Windows.Controls;

namespace ModuleB.Views
{
    /// <summary>
    /// Interaction logic for MessageList
    /// </summary>
    public partial class MessageList : UserControl
    {
        public MessageList()
        {
            InitializeComponent();
        }
    }
}

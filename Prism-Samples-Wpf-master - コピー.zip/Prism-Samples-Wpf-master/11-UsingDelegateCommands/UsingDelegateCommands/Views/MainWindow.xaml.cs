﻿using System.Windows;
using UsingDelegateCommands.ViewModels;

namespace UsingDelegateCommands.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow(MainWindowViewModel a)
        {
            InitializeComponent();
            if (a != null && string.IsNullOrEmpty(a.UpdateText))
            {
                if (a?.UpdateText == "")
                {
                    
                }
            }
            ;
        }
    }
}
